import Link from 'next/link';
export default function Landing() {
  return (
    <div className="wrap landing">
      <h1>Your AI chief of staff</h1>
      <p className="muted" style={{ maxWidth: 560, margin: '0 auto 28px' }}>Tell it about a meeting in your own words. It saves the meeting, tracks every promise, and shows you what to do next.</p>
      <Link className="btn grad" href="/login">Get started free</Link>
    </div>
  );
}
