'use client';
import { useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';

const NAV = [['dashboard', 'Dashboard'], ['chat', 'Chat'], ['meetings', 'Meetings'], ['commitments', 'Commitments']];

export default function AppLayout({ children }) {
  const { user, loading, signOut } = useAuth();
  const router = useRouter();
  const path = usePathname();
  useEffect(() => { if (!loading && !user) router.replace('/login'); }, [loading, user, router]);
  if (loading || !user) return <p className="muted" style={{ padding: 24 }}>Loading…</p>;
  return (
    <div className="shell">
      <aside className="side">
        <div className="logo"><i className="grad">PA</i>Personal Assistant</div>
        {NAV.map(([h, l]) => <Link key={h} href={'/' + h} className={'nav' + (path === '/' + h ? ' on' : '')}>{l}</Link>)}
        <div className="who">{user.displayName || user.email}<br /><button className="x" style={{ fontSize: 14, padding: 0, textDecoration: 'underline' }} onClick={signOut}>Sign out</button></div>
      </aside>
      <main>{children}</main>
    </div>
  );
}
