'use client';
import { useState } from 'react';
import { useItems } from '@/lib/data';
import { defaultWhen } from '@/lib/util';

export default function Meetings() {
  const { meetings, commits, loaded, api } = useItems();
  const [form, setForm] = useState({ title: '', when: defaultWhen(), people: '', notes: '' });
  if (!loaded) return <p className="muted">Loading…</p>;
  const add = async (e) => {
    e.preventDefault();
    if (!form.title.trim()) return;
    await api.add({ type: 'meeting', title: form.title.trim().slice(0, 120), when: form.when, people: form.people.trim().slice(0, 160), notes: form.notes.trim().slice(0, 20000), summary: '', decisions: [] });
    setForm({ title: '', when: defaultWhen(), people: '', notes: '' });
  };
  const sorted = [...meetings].sort((a, b) => (b.when || '').localeCompare(a.when || ''));
  return (
    <>
      <h1 style={{ marginBottom: 16 }}>Meetings</h1>
      <form className="card" onSubmit={add}>
        <label htmlFor="mt">Title</label><input id="mt" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <label>When</label><input type="datetime-local" value={form.when} onChange={(e) => setForm({ ...form, when: e.target.value })} />
        <label>People</label><input value={form.people} onChange={(e) => setForm({ ...form, people: e.target.value })} />
        <label>Notes</label><textarea rows={4} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        <button className="btn grad" style={{ marginTop: 16 }}>Save meeting</button>
        <p className="meta">Tip: paste raw notes into Chat instead and it adds the commitments for you.</p>
      </form>
      {sorted.map((m) => (
        <article className="card" key={m.id}>
          <div className="row" style={{ border: 0, padding: 0 }}>
            <div className="t"><h3>{m.title}</h3><p className="meta">{(m.when || '').replace('T', ' ')}{m.people ? ' · ' + m.people : ''}</p></div>
            <button className="x" aria-label="Remove meeting" onClick={() => confirm('Remove this meeting?') && api.remove(m.id)}>×</button>
          </div>
          {m.summary && <p>{m.summary}</p>}
          {(m.decisions || []).length > 0 && <p className="meta">Decisions: {m.decisions.join('; ')}</p>}
          <p className="meta">{commits.filter((c) => c.meetingId === m.id).length} commitments linked</p>
        </article>
      ))}
      {!sorted.length && <p className="muted">No meetings yet.</p>}
    </>
  );
}
