'use client';
import Link from 'next/link';
import { useItems } from '@/lib/data';
import { useAuth } from '@/lib/auth-context';
import { dueInfo, byDue, todayStr } from '@/lib/util';

export default function Dashboard() {
  const { user } = useAuth();
  const { commits, meetings, loaded, api } = useItems();
  if (!loaded) return <p className="muted">Loading…</p>;
  const open = commits.filter((c) => c.status !== 'done').sort(byDue);
  const count = (b) => open.filter((c) => dueInfo(c).bucket === b).length;
  const recent = [...meetings].sort((a, b) => (b.when || '').localeCompare(a.when || '')).slice(0, 5);
  const first = (user.displayName || '').split(' ')[0];
  return (
    <>
      <h1 style={{ marginBottom: 16 }}>{first ? `Hello, ${first}` : 'Dashboard'}</h1>
      <div className="tiles">
        <div className="tile"><span className="muted">Open</span><b>{open.length}</b></div>
        <div className="tile"><span className="muted">Overdue</span><b style={{ color: count('overdue') ? 'var(--late)' : undefined }}>{count('overdue')}</b></div>
        <div className="tile"><span className="muted">Due today</span><b>{count('today')}</b></div>
        <div className="tile"><span className="muted">Meetings</span><b>{meetings.length}</b></div>
      </div>
      <div className="card">
        <h2 style={{ marginBottom: 8 }}>Top commitments</h2>
        {open.slice(0, 6).map((c) => { const d = dueInfo(c); return (
          <div className="row" key={c.id}>
            <button className="check" aria-pressed="false" aria-label={'Mark done: ' + c.text} onClick={() => api.patch(c.id, { status: 'done', doneAt: Date.now() })} />
            <div className="t"><p>{c.text}</p><p className="meta">{c.dir === 'theirs' ? (c.person || 'Someone') + ' owes you' : 'You owe ' + (c.person || 'someone')}</p></div>
            <span className={'chip ' + d.cls}>{d.label}</span>
          </div>); })}
        {!open.length && <p className="muted">Nothing open. <Link href="/chat" style={{ textDecoration: 'underline' }}>Tell the chat about a meeting.</Link></p>}
      </div>
      <div className="card">
        <h2 style={{ marginBottom: 8 }}>Recent meetings</h2>
        {recent.map((m) => <div className="row" key={m.id}><div className="t"><p>{m.title}</p><p className="meta">{(m.when || '').replace('T', ' ')}{m.people ? ' · ' + m.people : ''}</p></div></div>)}
        {!recent.length && <p className="muted">No meetings yet.</p>}
      </div>
    </>
  );
}
