'use client';
import { useState } from 'react';
import { useItems } from '@/lib/data';
import { dueInfo, byDue } from '@/lib/util';

export default function Commitments() {
  const { commits, loaded, api } = useItems();
  const [f, setF] = useState('mine');
  const [form, setForm] = useState({ text: '', dir: 'mine', person: '', due: '' });
  if (!loaded) return <p className="muted">Loading…</p>;
  const list = commits.filter((c) => (f === 'done' ? c.status === 'done' : c.status !== 'done' && c.dir === f)).sort(byDue);
  const n = (k) => commits.filter((c) => (k === 'done' ? c.status === 'done' : c.status !== 'done' && c.dir === k)).length;
  const add = async (e) => {
    e.preventDefault();
    if (!form.text.trim()) return;
    await api.add({ type: 'commitment', text: form.text.trim().slice(0, 200), dir: form.dir, person: form.person.trim().slice(0, 60), due: form.due, status: 'open' });
    setForm({ ...form, text: '', person: '', due: '' });
  };
  return (
    <>
      <h1 style={{ marginBottom: 16 }}>Commitments</h1>
      <form className="card" onSubmit={add}>
        <label htmlFor="t">New commitment</label><input id="t" value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(140px,1fr))', gap: 12 }}>
          <div><label>Direction</label><select value={form.dir} onChange={(e) => setForm({ ...form, dir: e.target.value })}><option value="mine">I owe</option><option value="theirs">Owed to me</option></select></div>
          <div><label>Person</label><input value={form.person} onChange={(e) => setForm({ ...form, person: e.target.value })} /></div>
          <div><label>Due</label><input type="date" value={form.due} onChange={(e) => setForm({ ...form, due: e.target.value })} /></div>
        </div>
        <button className="btn grad" style={{ marginTop: 16 }}>Add</button>
      </form>
      <div className="pills">{[['mine', 'I owe'], ['theirs', 'Owed to me'], ['done', 'Done']].map(([k, l]) => <button key={k} className="pill" aria-pressed={f === k} onClick={() => setF(k)}>{l} · {n(k)}</button>)}</div>
      <div className="card">
        {list.map((c) => { const d = dueInfo(c), done = c.status === 'done'; return (
          <div className="row" key={c.id}>
            <button className="check" aria-pressed={done} aria-label={(done ? 'Reopen: ' : 'Mark done: ') + c.text} onClick={() => api.patch(c.id, { status: done ? 'open' : 'done', doneAt: done ? null : Date.now() })} />
            <div className="t"><p>{c.text}</p><p className="meta">{c.dir === 'theirs' ? (c.person || 'Someone') + ' owes you' : 'You owe ' + (c.person || 'someone')}</p></div>
            <span className={'chip ' + d.cls}>{d.label}</span>
            <button className="x" aria-label="Remove" onClick={() => confirm('Remove this commitment?') && api.remove(c.id)}>×</button>
          </div>); })}
        {!list.length && <p className="muted">Nothing here.</p>}
      </div>
    </>
  );
}
