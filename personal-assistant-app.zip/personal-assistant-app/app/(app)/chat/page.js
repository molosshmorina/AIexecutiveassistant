'use client';
import { useRef, useState } from 'react';
import { useAuth } from '@/lib/auth-context';
import { useItems } from '@/lib/data';

const STARTERS = [
  "Just met Dana from Sales. I'll send her the updated pricing deck by Friday, and she'll share two customer quotes by Tuesday.",
  'What did I promise this week?',
  'Who am I waiting on?',
];

export default function Chat() {
  const { user } = useAuth();
  const { api } = useItems();
  const [turns, setTurns] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const box = useRef(null);

  async function send(text) {
    text = (text || '').trim();
    if (!text || busy) return;
    const next = [...turns, { role: 'user', content: text }];
    setTurns(next); setBusy(true); setErr('');
    if (box.current) box.current.value = '';
    try {
      const token = await user.getIdToken();
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
        body: JSON.stringify({ messages: next.slice(-12).map((t) => ({ role: t.role, content: t.content })), today: new Date().toLocaleDateString('en-CA'), weekday: new Date().toLocaleDateString('en-GB', { weekday: 'long' }) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Request failed');
      setTurns([...next, { role: 'assistant', content: data.text, actions: data.actions }]);
    } catch (e) { setErr(e.message || 'Claude could not answer just now.'); }
    setBusy(false);
  }
  async function undo(ti, k) {
    const a = turns[ti].actions[k];
    if (a.undone) return;
    if (a.kind === 'done') await api.patch(a.id, { status: 'open', doneAt: null }); else await api.remove(a.id);
    setTurns((ts) => ts.map((t, i) => i !== ti ? t : { ...t, actions: t.actions.map((x, j) => j === k ? { ...x, undone: true } : x) }));
  }

  return (
    <>
      <h1 style={{ marginBottom: 16 }}>Chat</h1>
      {!turns.length && (
        <div className="card">
          <h2>Tell me what happened</h2>
          <p className="muted">Describe a meeting or a promise, or paste raw notes. I save the meeting and add each commitment. You can undo anything I add.</p>
          <div className="pills">{STARTERS.map((s) => <button key={s} className="pill" onClick={() => { box.current.value = s; box.current.focus(); }}>{s}</button>)}</div>
        </div>
      )}
      {turns.map((t, i) => (
        <div key={i} className={'turn ' + (t.role === 'user' ? 'you' : 'ai')}>
          {t.content}
          {(t.actions || []).map((a, k) => (
            <div key={k} className={'act' + (a.undone ? ' undone' : '')}>
              <div className="t"><b>{a.kind === 'meeting' ? 'Meeting saved' : a.kind === 'done' ? 'Marked done' : 'Commitment added'}:</b> {a.text}<div className="meta">{a.meta}</div></div>
              {a.undone ? <span className="chip">Undone</span> : <button className="pill" onClick={() => undo(i, k)}>Undo</button>}
            </div>
          ))}
        </div>
      ))}
      {busy && <p className="muted">Thinking…</p>}
      {err && <p className="err" role="alert">{err}</p>}
      <form className="askbar" onSubmit={(e) => { e.preventDefault(); send(box.current.value); }}>
        <textarea ref={box} rows={2} placeholder="Tell me about a meeting" onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(e.currentTarget.value); } }} />
        <button className="btn grad" disabled={busy}>Send</button>
      </form>
    </>
  );
}
