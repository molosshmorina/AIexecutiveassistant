'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { GoogleAuthProvider, signInWithPopup, createUserWithEmailAndPassword, signInWithEmailAndPassword, sendPasswordResetEmail, updateProfile } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { useAuth } from '@/lib/auth-context';

const MESSAGES = {
  'auth/invalid-credential': 'That email and password do not match.',
  'auth/email-already-in-use': 'An account with this email already exists. Sign in instead.',
  'auth/weak-password': 'Use a password of at least 8 characters.',
  'auth/invalid-email': 'Enter a valid email address.',
  'auth/popup-closed-by-user': '',
  'auth/cancelled-popup-request': '',
  'auth/too-many-requests': 'Too many attempts. Try again in a few minutes.',
};

export default function Login() {
  const router = useRouter();
  const { user } = useAuth();
  const [mode, setMode] = useState('signin');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (user) router.replace('/dashboard'); }, [user, router]);

  async function run(fn) {
    setErr(''); setInfo(''); setBusy(true);
    try { await fn(); } catch (e) { setErr(MESSAGES[e.code] ?? 'Something went wrong. Try again.'); }
    setBusy(false);
  }
  const google = () => run(() => signInWithPopup(auth, new GoogleAuthProvider()));
  const submit = (e) => {
    e.preventDefault();
    run(async () => {
      if (mode === 'create') {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
        if (name.trim()) await updateProfile(cred.user, { displayName: name.trim() });
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), pass);
      }
    });
  };
  const reset = () => {
    if (!email.trim()) { setErr('Enter your email first.'); return; }
    run(async () => { await sendPasswordResetEmail(auth, email.trim()); setInfo('Password reset email sent.'); });
  };

  return (
    <div className="wrap">
      <div className="card authbox">
        <h1 style={{ fontSize: 26, marginBottom: 16 }}>{mode === 'create' ? 'Create your account' : 'Welcome back'}</h1>
        <button className="btn google wide" onClick={google} disabled={busy} type="button">Continue with Google</button>
        <div className="or">or use email</div>
        <div className="tabs">
          <button type="button" className={'tab' + (mode === 'signin' ? ' on' : '')} onClick={() => setMode('signin')}>Sign in</button>
          <button type="button" className={'tab' + (mode === 'create' ? ' on' : '')} onClick={() => setMode('create')}>Create account</button>
        </div>
        <form onSubmit={submit}>
          {mode === 'create' && (<><label htmlFor="n">Name</label><input id="n" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" /></>)}
          <label htmlFor="e">Email</label><input id="e" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="email" />
          <label htmlFor="p">Password</label><input id="p" type="password" required minLength={8} value={pass} onChange={(e) => setPass(e.target.value)} autoComplete={mode === 'create' ? 'new-password' : 'current-password'} />
          {err && <p className="err" role="alert">{err}</p>}
          {info && <p className="muted">{info}</p>}
          <button className="btn grad wide" style={{ marginTop: 16 }} disabled={busy}>{mode === 'create' ? 'Create account' : 'Sign in'}</button>
          {mode === 'signin' && <p style={{ textAlign: 'center' }}><button type="button" className="x" style={{ fontSize: 14, textDecoration: 'underline' }} onClick={reset}>Forgot password?</button></p>}
        </form>
      </div>
    </div>
  );
}
