import { adminAuth, adminDb } from '@/lib/admin';

export const runtime = 'nodejs';
export const maxDuration = 60;

const MODEL = process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
const str = (v, n) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const ymdRe = /^\d{4}-\d{2}-\d{2}$/;
const whenRe = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/;

const TOOLS = [
  { name: 'add_meeting', description: "Save a meeting or call to the user's memory. Returns its id. Call this first, then use the id as meeting_id when adding that meeting's commitments.",
    input_schema: { type: 'object', properties: { title: { type: 'string' }, when: { type: 'string', description: 'YYYY-MM-DDTHH:MM local time; omit if unknown' }, people: { type: 'string' }, summary: { type: 'string', description: 'two plain sentences' }, decisions: { type: 'array', items: { type: 'string' } }, notes: { type: 'string', description: 'the raw notes the user gave' } }, required: ['title'] } },
  { name: 'add_commitment', description: 'Save one commitment. dir is "mine" when the user owes it, "theirs" when someone else owes the user.',
    input_schema: { type: 'object', properties: { text: { type: 'string', description: 'starts with a verb' }, dir: { type: 'string', enum: ['mine', 'theirs'] }, person: { type: 'string' }, due: { type: 'string', description: 'YYYY-MM-DD or empty' }, meeting_id: { type: 'string' } }, required: ['text', 'dir'] } },
  { name: 'complete_commitment', description: 'Mark an existing open commitment done, using its id from the DATA.',
    input_schema: { type: 'object', properties: { id: { type: 'string' } }, required: ['id'] } },
];

export async function POST(req) {
  let uid;
  try {
    const token = (req.headers.get('authorization') || '').replace(/^Bearer /, '');
    uid = (await adminAuth().verifyIdToken(token)).uid;
  } catch {
    return Response.json({ error: 'Please sign in again.' }, { status: 401 });
  }
  const body = await req.json().catch(() => ({}));
  const messages = Array.isArray(body.messages) ? body.messages.filter((m) => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string' && m.content) : [];
  while (messages.length && messages[0].role !== 'user') messages.shift();
  if (!messages.length || messages[messages.length - 1].role !== 'user') return Response.json({ error: 'Send a message.' }, { status: 400 });

  const col = adminDb().collection(`users/${uid}/items`);
  const snap = await col.get();
  const items = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  const ms = items.filter((x) => x.type === 'meeting').sort((a, b) => (b.when || '').localeCompare(a.when || '')).slice(0, 25)
    .map((m) => `- [id ${m.id}] ${m.when} "${m.title}" with ${m.people || 'n/a'}\n  summary: ${m.summary || '(none)'}\n  notes: ${String(m.notes || '').slice(0, 1000)}`).join('\n');
  const cs = items.filter((x) => x.type === 'commitment').sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999')).slice(0, 120)
    .map((c) => `- [id ${c.id}] ${c.status === 'done' ? 'DONE' : 'OPEN'} | ${c.dir === 'theirs' ? (c.person || 'Someone') + ' owes me' : 'I owe ' + (c.person || 'no one in particular')} | ${c.text} | due ${c.due || 'none'}`).join('\n');
  const today = ymdRe.test(body.today || '') ? body.today : new Date().toISOString().slice(0, 10);

  const system = `You are the user's chief of staff inside their Personal Assistant app. Today is ${str(body.weekday, 20)} ${today}.
When the user describes a meeting, a call or a promise, or pastes notes, save it with your tools instead of only talking about it: call add_meeting once, wait for its returned id, then call add_commitment for each clear promise with that id as meeting_id. If there is only a promise with no meeting, call add_commitment alone. When the user says something is done, call complete_commitment with an id from the DATA. Never save something that is already in the DATA. Do not invent promises, people or dates; leave due empty when none was given and resolve relative dates against today. "mine" means the user owes it, "theirs" means someone else owes the user.
Questions that need no saving are answered only from the DATA. If the answer is not there, say so. After saving, reply in one or two plain sentences saying what you saved. Be brief, name people and dates, use plain text with no markdown symbols.

DATA
MEETINGS (newest first):
${ms || '(none)'}

COMMITMENTS:
${cs || '(none)'}`;

  const actions = [];
  const newMeetings = new Set();
  const known = new Map(items.map((x) => [x.id, x]));

  async function runTool(name, i) {
    if (actions.length >= 30) throw new Error('Limit of 30 saves per message reached.');
    if (name === 'add_meeting') {
      const title = str(i.title, 120); if (!title) throw new Error('title is required');
      const when = whenRe.test(i.when || '') ? i.when : today + 'T09:00';
      const decisions = (Array.isArray(i.decisions) ? i.decisions : []).map((x) => str(String(x), 160)).filter(Boolean).slice(0, 8);
      const ref = await col.add({ type: 'meeting', title, when, people: str(i.people, 160), notes: str(i.notes, 20000), summary: str(i.summary, 600), decisions, createdAt: Date.now() });
      newMeetings.add(ref.id);
      actions.push({ kind: 'meeting', id: ref.id, text: title, meta: when.replace('T', ' ') + (i.people ? ' · ' + str(i.people, 60) : '') });
      return { id: ref.id };
    }
    if (name === 'add_commitment') {
      const text = str(i.text, 200); if (!text) throw new Error('text is required');
      let mid = str(i.meeting_id, 60);
      if (mid && !newMeetings.has(mid) && known.get(mid)?.type !== 'meeting') mid = '';
      const doc = { type: 'commitment', text, dir: i.dir === 'theirs' ? 'theirs' : 'mine', person: str(i.person, 60), due: ymdRe.test(i.due || '') ? i.due : '', status: 'open', createdAt: Date.now() };
      if (mid) doc.meetingId = mid;
      const ref = await col.add(doc);
      actions.push({ kind: 'commitment', id: ref.id, text, meta: (doc.dir === 'theirs' ? (doc.person || 'Someone') + ' owes you' : 'You owe ' + (doc.person || 'someone')) + ' · ' + (doc.due || 'No date') });
      return { id: ref.id };
    }
    if (name === 'complete_commitment') {
      const id = str(i.id, 60), c = known.get(id);
      if (!c || c.type !== 'commitment') throw new Error('No commitment with that id.');
      if (c.status === 'done') return 'Already done.';
      await col.doc(id).update({ status: 'done', doneAt: Date.now() });
      actions.push({ kind: 'done', id, text: c.text, meta: 'Marked done' });
      return 'ok';
    }
    throw new Error('Unknown tool.');
  }

  try {
    const convo = messages.map((m) => ({ role: m.role, content: m.content }));
    let text = '';
    for (let round = 0; round < 6; round++) {
      const r = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY || '', 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: MODEL, max_tokens: 1500, system, tools: TOOLS, messages: convo }),
      });
      if (!r.ok) throw new Error('Anthropic API ' + r.status + ' ' + (await r.text()).slice(0, 300));
      const res = await r.json();
      text = res.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim() || text;
      if (res.stop_reason !== 'tool_use') break;
      convo.push({ role: 'assistant', content: res.content });
      const results = [];
      for (const b of res.content.filter((x) => x.type === 'tool_use')) {
        try { results.push({ type: 'tool_result', tool_use_id: b.id, content: JSON.stringify(await runTool(b.name, b.input || {})) }); }
        catch (e) { results.push({ type: 'tool_result', tool_use_id: b.id, is_error: true, content: 'Error: ' + e.message }); }
      }
      convo.push({ role: 'user', content: results });
    }
    return Response.json({ text: text || (actions.length ? 'Saved.' : 'I have nothing to add.'), actions });
  } catch (e) {
    console.error(e);
    return Response.json({ error: actions.length ? 'Saved part of it, then Claude stopped. Check Commitments.' : 'Claude could not answer just now. Try again.', actions }, { status: 502 });
  }
}
